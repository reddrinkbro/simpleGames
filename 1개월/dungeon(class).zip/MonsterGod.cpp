#include "MonsterGod.h"



MonsterGod::MonsterGod()
{
	_name = "��";
}


MonsterGod::~MonsterGod()
{
}
