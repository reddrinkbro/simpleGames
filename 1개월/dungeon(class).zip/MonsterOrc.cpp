#include "MonsterOrc.h"



MonsterOrc::MonsterOrc()
{
	_name = "��ũ";
}


MonsterOrc::~MonsterOrc()
{
}
