#include "MonsterGoblin.h"



MonsterGoblin::MonsterGoblin()
{
	_name = "������";
}


MonsterGoblin::~MonsterGoblin()
{
}
