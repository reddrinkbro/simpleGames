#include "MonsterDragon.h"



MonsterDragon::MonsterDragon()
{
	_name = "�巡��";
}


MonsterDragon::~MonsterDragon()
{
}
