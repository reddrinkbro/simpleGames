#include "mainGame.h"

int main()
{
	mainGame* main = new mainGame;

	return 0;
}