#include "player.h"



player::player()
{
	_name = "�÷��̾�";
}


player::~player()
{
}
