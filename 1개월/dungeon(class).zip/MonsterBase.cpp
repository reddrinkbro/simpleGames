#include "MonsterBase.h"



MonsterBase::MonsterBase()
{
}


MonsterBase::~MonsterBase()
{
}
