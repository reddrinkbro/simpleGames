#include "MonsterTroll.h"



MonsterTroll::MonsterTroll()
{
	_name = "Ʈ��";
}


MonsterTroll::~MonsterTroll()
{
}
