#include "armor.h"

armor::armor()
{
	setName("����");
	setPrice(1000);
}


armor::~armor()
{
}
