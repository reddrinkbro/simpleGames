#pragma once
#include "shop.h"
class yellowPotion : public shop
{
public:
	yellowPotion();
	~yellowPotion();
};

