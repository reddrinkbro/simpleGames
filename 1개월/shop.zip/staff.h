#pragma once
#include "shop.h"
class staff : public shop
{
public:
	staff();
	~staff();
};

