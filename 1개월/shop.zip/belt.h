#pragma once
#include "shop.h"
class belt : public shop
{
public:
	belt();
	~belt();
};

