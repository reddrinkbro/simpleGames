#include "belt.h"



belt::belt()
{
	setName("��Ʈ");
	setPrice(900);
}


belt::~belt()
{
}
