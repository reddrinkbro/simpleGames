#include "gloves.h"



gloves::gloves()
{
	setName("�尩");
	setPrice(800);
}


gloves::~gloves()
{
}
