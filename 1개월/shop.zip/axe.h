#pragma once
#include "shop.h"
class axe : public shop
{
public:
	axe();
	~axe();
};

