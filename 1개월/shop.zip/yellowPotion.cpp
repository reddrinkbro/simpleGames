#include "yellowPotion.h"



yellowPotion::yellowPotion()
{
	setName("�������");
	setPrice(500);
}


yellowPotion::~yellowPotion()
{
}
