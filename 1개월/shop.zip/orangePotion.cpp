#include "orangePotion.h"



orangePotion::orangePotion()
{
	setName("��Ȳ����");
	setPrice(300);
}


orangePotion::~orangePotion()
{
}
