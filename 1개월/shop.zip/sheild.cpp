#include "sheild.h"



sheild::sheild()
{
	setName("����");
	setPrice(1200);
}


sheild::~sheild()
{
}
