#include "sword.h"



sword::sword()
{
	setName("��");
	setPrice(1000);
}


sword::~sword()
{
}
