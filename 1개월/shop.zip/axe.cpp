#include "axe.h"



axe::axe()
{
	setName("����");
	setPrice(1400);
}


axe::~axe()
{
}
