#pragma once
#include "shop.h"
class sheild : public shop
{
public:
	sheild();
	~sheild();
};

