#include "spear.h"



spear::spear()
{
	setName("â");
	setPrice(1300);
}


spear::~spear()
{
}
