#pragma once
#include "shop.h"
class shoes : public shop
{
public:
	
	shoes();
	~shoes();
};

