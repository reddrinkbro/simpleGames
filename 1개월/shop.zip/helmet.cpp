#include "helmet.h"



helmet::helmet()
{
	setName("����");
	setPrice(1100);
}


helmet::~helmet()
{
}
