#include "shoes.h"



shoes::shoes()
{
	setName("�Ź�");
	setPrice(600);
}


shoes::~shoes()
{
}
