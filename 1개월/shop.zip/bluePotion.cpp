#include "bluePotion.h"


bluePotion::bluePotion()
{
	setName("�Ķ�����");
	setPrice(200);
}


bluePotion::~bluePotion()
{
}
