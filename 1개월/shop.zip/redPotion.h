#pragma once
#include "shop.h"
class redPotion : public shop
{
public:
	redPotion();
	~redPotion();
};

