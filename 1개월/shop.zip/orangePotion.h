#pragma once
#include "shop.h"
class orangePotion : public shop
{
public:
	orangePotion();
	~orangePotion();
};

