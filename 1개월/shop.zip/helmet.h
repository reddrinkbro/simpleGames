#pragma once
#include "shop.h"
class helmet : public shop
{
public:
	helmet();
	~helmet();
};

