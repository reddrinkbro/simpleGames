#pragma once
#include "shop.h"
class armor : public shop
{
public:
	armor();
	~armor();
};

