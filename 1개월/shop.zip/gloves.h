#pragma once
#include "shop.h"
class gloves : public shop
{
public:
	gloves();
	~gloves();
};

