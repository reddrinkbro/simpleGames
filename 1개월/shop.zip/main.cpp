#include "mainShop.h"

int main()
{
	
	mainShop* main = new mainShop;
	
	delete main;
	
	return 0;
}