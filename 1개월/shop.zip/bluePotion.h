#pragma once
#include "shop.h"
class bluePotion : public shop
{
public:
	bluePotion();
	~bluePotion();
};

