#pragma once
#include "shop.h"
class sword : public shop
{
public:
	sword();
	~sword();
};

