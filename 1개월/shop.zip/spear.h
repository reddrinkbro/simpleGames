#pragma once
#include "shop.h"
class spear : public shop
{
public:
	spear();
	~spear();
};

