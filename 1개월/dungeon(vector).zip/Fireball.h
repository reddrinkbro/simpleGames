#pragma once
#include "skillBase.h"
class Fireball : public skillBase
{
public:
	Fireball();
	~Fireball();
};

