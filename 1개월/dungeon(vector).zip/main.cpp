#include "mainGame.h"

int main()
{
	srand(time(NULL));
	mainGame* main = new mainGame;
	delete main;
	return 0;
}