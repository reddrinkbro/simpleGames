#include "magicBolt.h"



magicBolt::magicBolt()
{
	setName("������Ʈ");
	setDamage(300);
}


magicBolt::~magicBolt()
{
}
