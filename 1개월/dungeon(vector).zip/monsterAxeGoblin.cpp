#include "monsterAxeGoblin.h"



monsterAxeGoblin::monsterAxeGoblin()
{
	setName("���� ������");
	setMaxHp(150);
	setCurHp(getMaxHp());
	setAtk(15);
	setDef(10);
	
}


monsterAxeGoblin::~monsterAxeGoblin()
{
}
