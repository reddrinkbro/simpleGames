#pragma once
#include "itemBase.h"
class gloves : public itemBase
{
public:
	gloves();
	~gloves();
};

