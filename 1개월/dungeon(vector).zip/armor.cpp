#include "armor.h"

armor::armor()
{
	setName("����");
}


armor::~armor()
{
}
