#pragma once
#include "monsterBase.h"
class monsterBigTroll :
	public monsterBase
{
public:
	monsterBigTroll();
	~monsterBigTroll();
};

