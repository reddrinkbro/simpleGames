#include "shoes.h"



shoes::shoes()
{
	setName("�Ź�");
}


shoes::~shoes()
{
}
