#include "trollGround.h"



trollGround::trollGround()
{
	setName("Ʈ���� ��");
	
}


trollGround::~trollGround()
{
}

