#pragma once
#include "skillBase.h"
class magicBolt : public skillBase
{
public:
	magicBolt();
	~magicBolt();
};

