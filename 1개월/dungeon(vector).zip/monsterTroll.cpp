#include "monsterTroll.h"



monsterTroll::monsterTroll()
{
	setName("Ʈ��");
	setMaxHp(300);
	setCurHp(getMaxHp());
	setAtk(30);
	setDef(20);
}


monsterTroll::~monsterTroll()
{
}
