#include "monsterBigTroll.h"



monsterBigTroll::monsterBigTroll()
{
	setName("�Ŵ� Ʈ��");
	setMaxHp(500);
	setCurHp(getMaxHp());
	setAtk(45);
	setDef(30);
}


monsterBigTroll::~monsterBigTroll()
{
}
