#pragma once
#include "mapBase.h"
class trollGround : public mapBase
{
public:
	
	trollGround();
	~trollGround();
};

