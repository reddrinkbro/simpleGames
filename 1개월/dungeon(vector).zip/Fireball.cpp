#include "Fireball.h"



Fireball::Fireball()
{
	setName("���̾");
	setDamage(100);
}


Fireball::~Fireball()
{
}
