#pragma once
#include "itemBase.h"
class shoes : public itemBase
{
public:
	
	shoes();
	~shoes();
};

