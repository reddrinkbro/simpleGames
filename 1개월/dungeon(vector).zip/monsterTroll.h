#pragma once
#include "monsterBase.h"
class monsterTroll : public monsterBase
{
public:
	monsterTroll();
	~monsterTroll();
};

