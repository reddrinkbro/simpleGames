#pragma once
#include "monsterBase.h"
class montserGoblin : public monsterBase
{
public:
	montserGoblin();
	~montserGoblin();
};

