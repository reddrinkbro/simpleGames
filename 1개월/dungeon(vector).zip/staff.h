#pragma once
#include "itemBase.h"
class staff : public itemBase
{
public:
	staff();
	~staff();
};

