#include "helmet.h"



helmet::helmet()
{
	setName("����");
}


helmet::~helmet()
{
}
