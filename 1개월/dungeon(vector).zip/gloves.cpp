#include "gloves.h"



gloves::gloves()
{
	setName("�尩");
}


gloves::~gloves()
{
}
