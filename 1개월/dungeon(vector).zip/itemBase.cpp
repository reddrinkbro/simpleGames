#include "itemBase.h"



itemBase::itemBase()
{
}


itemBase::~itemBase()
{
}
