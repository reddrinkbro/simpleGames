#include "montserGoblin.h"



montserGoblin::montserGoblin()
{
	setName("������");
	setMaxHp(100);
	setCurHp(getMaxHp());
	setAtk(10);
	setDef(5);
}


montserGoblin::~montserGoblin()
{
}
