#pragma once
#include "skillBase.h"
class iceAge : public skillBase
{
public:
	iceAge();
	~iceAge();
};

