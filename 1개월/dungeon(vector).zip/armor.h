#pragma once
#include "itemBase.h"
class armor : public itemBase
{
public:
	armor();
	~armor();
};

