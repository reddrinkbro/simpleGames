#pragma once
#include "itemBase.h"
class helmet : public itemBase
{
public:
	helmet();
	~helmet();
};

