#pragma once
#include "mapBase.h"
class goblinGround : public mapBase
{
public:
	goblinGround();
	~goblinGround();
};

