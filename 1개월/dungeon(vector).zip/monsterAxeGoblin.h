#pragma once
#include "monsterBase.h"
class monsterAxeGoblin : public monsterBase
{
public:
	monsterAxeGoblin();
	~monsterAxeGoblin();
};

